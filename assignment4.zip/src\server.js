const app = require('./app');
const config = require('./config/env');
const { supabase } = require('./config/supabaseClient');

const PORT = config.PORT;

const server = app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  if (supabase) {
    console.log('Server running and connected to Supabase');
  }
});

module.exports = server;
