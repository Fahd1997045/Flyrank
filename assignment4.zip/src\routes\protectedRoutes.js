const express = require('express');
const authenticateToken = require('../middleware/authMiddleware');

const router = express.Router();

// Apply authMiddleware to all routes in this router
router.use(authenticateToken);

/**
 * GET /protected/profile
 * Reads private user profile data.
 * Protected by authMiddleware.
 */
router.get('/profile', (req, res) => {
  const user = req.user;

  return res.status(200).json({
    message: 'Access granted to protected profile',
    profile: {
      id: user.id,
      email: user.email,
      created_at: user.created_at,
      last_sign_in_at: user.last_sign_in_at,
      app_metadata: user.app_metadata,
      user_metadata: user.user_metadata,
      role: user.role || 'authenticated'
    }
  });
});

/**
 * GET /protected/dashboard
 * Second protected route demonstrating middleware reusability.
 * Protected by authMiddleware.
 */
router.get('/dashboard', (req, res) => {
  const user = req.user;

  return res.status(200).json({
    message: `Welcome to your private dashboard, ${user.email}!`,
    stats: {
      accountAgeDays: Math.floor((Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24)),
      securityStatus: 'JWT Verified via Supabase',
      authenticatedAt: new Date().toISOString()
    },
    user: {
      id: user.id,
      email: user.email
    }
  });
});

module.exports = router;
