const { createClient } = require('@supabase/supabase-js');
const WebSocket = require('ws');
const config = require('./env');

let activeSupabaseClient = null;

/**
 * Initializes or retrieves the current Supabase client.
 * @returns {import('@supabase/supabase-js').SupabaseClient}
 */
function getSupabaseClient() {
  if (activeSupabaseClient) {
    return activeSupabaseClient;
  }

  activeSupabaseClient = createClient(config.SUPABASE_URL, config.SUPABASE_KEY, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    },
    realtime: {
      transport: WebSocket
    }
  });

  return activeSupabaseClient;
}

/**
 * Injects a mock or custom Supabase client (useful for automated testing or runtime switching).
 * @param {any} client
 */
function setSupabaseClient(client) {
  activeSupabaseClient = client;
}

module.exports = {
  getSupabaseClient,
  setSupabaseClient,
  // Getter property for backward compatibility
  get supabase() {
    return getSupabaseClient();
  }
};
