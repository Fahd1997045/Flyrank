const { getSupabaseClient } = require('../config/supabaseClient');

/**
 * Express Middleware to authenticate incoming requests via Supabase JWT Bearer tokens.
 * Extracts the token, verifies it with Supabase Auth, and attaches the user object to `req.user`.
 * 
 * Status Codes:
 *  - 401 Unauthorized: When Authorization header is missing, malformed, or token is invalid/expired
 */
async function authenticateToken(req, res, next) {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Access token required' });
    }

    const token = authHeader.split(' ')[1];
    if (!token || token.trim() === '') {
      return res.status(401).json({ error: 'Access token required' });
    }

    const supabase = getSupabaseClient();
    // Verify token with Supabase Auth IdP
    const { data, error } = await supabase.auth.getUser(token);

    if (error || !data || !data.user) {
      return res.status(401).json({
        error: 'Invalid or expired token',
        details: error ? error.message : 'User session not found'
      });
    }

    // Attach validated user and token to request
    req.user = data.user;
    req.token = token;

    next();
  } catch (err) {
    console.error('Authentication middleware error:', err);
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

module.exports = authenticateToken;
