const assert = require('assert');
const app = require('./src/app');
const { setSupabaseClient } = require('./src/config/supabaseClient');

const TEST_PORT = 4288;
const BASE_URL = `http://localhost:${TEST_PORT}`;

async function runAuthTests() {
  console.log('='.repeat(70));
  console.log('   RUNNING ASSIGNMENT 4 SUPABASE AUTH & SECURITY TEST SUITE');
  console.log('='.repeat(70));

  let passed = 0;
  let total = 0;

  async function test(name, fn) {
    total++;
    try {
      await fn();
      console.log(`  ✔ [PASS] ${name}`);
      passed++;
    } catch (err) {
      console.error(`  ✖ [FAIL] ${name}`);
      console.error(err);
    }
  }

  // Setup mock Supabase client for deterministic automated testing
  const mockUser = {
    id: 'a8123456-7890-abcd-ef01-234567890abc',
    email: 'developer@flyrank.ai',
    created_at: '2026-09-12T12:00:00.000Z',
    last_sign_in_at: '2026-09-12T14:00:00.000Z',
    app_metadata: { provider: 'email' },
    user_metadata: { name: 'FlyRank Developer' },
    role: 'authenticated'
  };

  const VALID_MOCK_TOKEN = 'mock-valid-jwt-token-12345';

  const mockSupabase = {
    auth: {
      async signUp({ email, password }) {
        if (!email || !password) {
          return { data: null, error: { message: 'Missing credentials' } };
        }
        return {
          data: {
            user: { ...mockUser, email },
            session: { access_token: VALID_MOCK_TOKEN, refresh_token: 'mock-refresh-token', expires_in: 3600 }
          },
          error: null
        };
      },
      async signInWithPassword({ email, password }) {
        if (password === 'wrongpassword') {
          return { data: { user: null, session: null }, error: { message: 'Invalid login credentials' } };
        }
        return {
          data: {
            user: { ...mockUser, email },
            session: { access_token: VALID_MOCK_TOKEN, refresh_token: 'mock-refresh-token', expires_in: 3600 }
          },
          error: null
        };
      },
      async getUser(token) {
        if (token === VALID_MOCK_TOKEN) {
          return { data: { user: mockUser }, error: null };
        }
        return { data: { user: null }, error: { message: 'Invalid or expired token' } };
      },
      async signOut() {
        return { error: null };
      }
    }
  };

  setSupabaseClient(mockSupabase);

  const server = app.listen(TEST_PORT);

  try {
    // 1. Public Route Test
    await test('GET /public/info returns 200 without authentication', async () => {
      const res = await fetch(`${BASE_URL}/public/info`);
      assert.strictEqual(res.status, 200);
      const data = await res.json();
      assert.ok(data.message.includes('Welcome stranger'));
    });

    // 2. Signup Validation & Execution
    await test('POST /auth/signup returns 400 if email or password missing', async () => {
      const res1 = await fetch(`${BASE_URL}/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'onlyemail@flyrank.ai' })
      });
      assert.strictEqual(res1.status, 400);

      const res2 = await fetch(`${BASE_URL}/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      assert.strictEqual(res2.status, 400);
    });

    await test('POST /auth/signup returns 201 on valid registration', async () => {
      const res = await fetch(`${BASE_URL}/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'newuser@flyrank.ai', password: 'Password123!' })
      });
      assert.strictEqual(res.status, 201);
      const data = await res.json();
      assert.strictEqual(data.message, 'User registered successfully');
      assert.ok(data.user);
    });

    // 3. Login Validation & Authentication
    await test('POST /auth/login returns 400 if fields are empty', async () => {
      const res = await fetch(`${BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: '', password: '' })
      });
      assert.strictEqual(res.status, 400);
    });

    await test('POST /auth/login returns 401 for incorrect credentials', async () => {
      const res = await fetch(`${BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'developer@flyrank.ai', password: 'wrongpassword' })
      });
      assert.strictEqual(res.status, 401);
      const data = await res.json();
      assert.strictEqual(data.error, 'Invalid login credentials');
    });

    let accessToken;
    await test('POST /auth/login returns 200 with JWT access_token on success', async () => {
      const res = await fetch(`${BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'developer@flyrank.ai', password: 'CorrectPassword123!' })
      });
      assert.strictEqual(res.status, 200);
      const data = await res.json();
      assert.strictEqual(data.message, 'Login successful');
      assert.ok(data.access_token);
      assert.strictEqual(data.token_type, 'bearer');
      accessToken = data.access_token;
    });

    // 4. Protected Route: GET /protected/profile
    await test('GET /protected/profile returns 401 when Authorization header is missing', async () => {
      const res = await fetch(`${BASE_URL}/protected/profile`);
      assert.strictEqual(res.status, 401);
      const data = await res.json();
      assert.strictEqual(data.error, 'Access token required');
    });

    await test('GET /protected/profile returns 401 when token is invalid or tampered', async () => {
      const res = await fetch(`${BASE_URL}/protected/profile`, {
        headers: { 'Authorization': 'Bearer tampered-invalid-jwt-xyz' }
      });
      assert.strictEqual(res.status, 401);
      const data = await res.json();
      assert.strictEqual(data.error, 'Invalid or expired token');
    });

    await test('GET /protected/profile returns 200 and user profile with valid Bearer token', async () => {
      const res = await fetch(`${BASE_URL}/protected/profile`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      assert.strictEqual(res.status, 200);
      const data = await res.json();
      assert.strictEqual(data.profile.email, 'developer@flyrank.ai');
      assert.strictEqual(data.profile.id, mockUser.id);
    });

    // 5. Middleware Reusability: GET /protected/dashboard
    await test('GET /protected/dashboard returns 401 without token, 200 with valid token', async () => {
      const unauth = await fetch(`${BASE_URL}/protected/dashboard`);
      assert.strictEqual(unauth.status, 401);

      const auth = await fetch(`${BASE_URL}/protected/dashboard`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      assert.strictEqual(auth.status, 200);
      const data = await auth.json();
      assert.ok(data.message.includes('Welcome to your private dashboard'));
    });

    // 6. Logout Endpoint: POST /auth/logout
    await test('POST /auth/logout returns 401 without token, 204 No Content with valid token', async () => {
      const unauth = await fetch(`${BASE_URL}/auth/logout`, { method: 'POST' });
      assert.strictEqual(unauth.status, 401);

      const auth = await fetch(`${BASE_URL}/auth/logout`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      assert.strictEqual(auth.status, 204);
    });

    // 7. Swagger Documentation Endpoint
    await test('GET /docs returns 200 for Swagger UI documentation', async () => {
      const res = await fetch(`${BASE_URL}/docs/`);
      assert.strictEqual(res.status, 200);
      const html = await res.text();
      assert.ok(html.includes('Swagger UI') || html.includes('swagger'));
    });

  } finally {
    server.close();
  }

  console.log('='.repeat(70));
  console.log(`Test Results: ${passed}/${total} passed`);
  console.log('='.repeat(70));

  if (passed !== total) {
    process.exit(1);
  }
}

runAuthTests().catch(err => {
  console.error('Test execution error:', err);
  process.exit(1);
});
