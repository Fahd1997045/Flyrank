const express = require('express');

const router = express.Router();

/**
 * GET /public/info
 * Publicly accessible endpoint requiring no authentication.
 * Returns 200 OK.
 */
router.get('/info', (req, res) => {
  return res.status(200).json({
    message: 'Welcome stranger! This info is public.',
    access: 'unrestricted',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
