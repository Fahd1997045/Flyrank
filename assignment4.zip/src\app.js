const express = require('express');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');
const openapiDocument = require('./docs/openapi.json');
const { supabase } = require('./config/supabaseClient');
const authRoutes = require('./routes/authRoutes');
const publicRoutes = require('./routes/publicRoutes');
const protectedRoutes = require('./routes/protectedRoutes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Swagger UI Documentation with Bearer Auth
app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapiDocument, {
  customSiteTitle: 'FlyRank Auth API Documentation',
  customCss: '.swagger-ui .topbar { display: none }',
  swaggerOptions: {
    persistAuthorization: true
  }
}));

// Routes
app.use('/auth', authRoutes);
app.use('/public', publicRoutes);
app.use('/protected', protectedRoutes);

// Root Welcome Route with redirect/links to Swagger
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'Welcome to the FlyRank Auth Login & Protect API',
    documentation: 'Interactive Swagger UI available at /docs',
    endpoints: {
      swaggerDocs: 'GET /docs',
      publicInfo: 'GET /public/info',
      signup: 'POST /auth/signup',
      login: 'POST /auth/login',
      logout: 'POST /auth/logout (Protected)',
      profile: 'GET /protected/profile (Protected)',
      dashboard: 'GET /protected/dashboard (Protected)'
    }
  });
});

// Basic health check route
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    supabaseConnected: Boolean(supabase)
  });
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Central Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  res.status(500).json({ error: 'Internal Server Error' });
});

module.exports = app;
