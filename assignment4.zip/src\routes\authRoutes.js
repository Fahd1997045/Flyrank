const express = require('express');
const { getSupabaseClient } = require('../config/supabaseClient');
const authenticateToken = require('../middleware/authMiddleware');

const router = express.Router();

/**
 * POST /auth/signup
 * Register a new user account with Supabase Auth.
 * Status Codes:
 *  - 201 Created on success
 *  - 400 Bad Request on missing inputs or signup error
 */
router.post('/signup', async (req, res) => {
  try {
    const { email, password } = req.body || {};

    if (!email || typeof email !== 'string' || email.trim() === '' ||
        !password || typeof password !== 'string' || password.trim() === '') {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const supabase = getSupabaseClient();
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password: password.trim()
    });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    return res.status(201).json({
      message: 'User registered successfully',
      user: data.user,
      session: data.session
    });
  } catch (err) {
    console.error('Signup error:', err);
    return res.status(500).json({ error: 'Internal server error during registration' });
  }
});

/**
 * POST /auth/login
 * Authenticate user with Supabase Auth and return JWT tokens.
 * Status Codes:
 *  - 200 OK on successful login with access_token & refresh_token
 *  - 400 Bad Request if fields are empty
 *  - 401 Unauthorized if invalid credentials
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};

    if (!email || typeof email !== 'string' || email.trim() === '' ||
        !password || typeof password !== 'string' || password.trim() === '') {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const supabase = getSupabaseClient();
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password: password.trim()
    });

    if (error) {
      return res.status(401).json({
        error: 'Invalid login credentials',
        details: error.message
      });
    }

    return res.status(200).json({
      message: 'Login successful',
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
      token_type: 'bearer',
      expires_in: data.session.expires_in,
      user: data.user
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Internal server error during authentication' });
  }
});

/**
 * POST /auth/logout
 * Terminate the user session with Supabase Auth.
 * Protected by authMiddleware.
 * Status Codes:
 *  - 204 No Content on successful logout
 *  - 401 Unauthorized if token missing/invalid
 */
router.post('/logout', authenticateToken, async (req, res) => {
  try {
    const supabase = getSupabaseClient();
    const { error } = await supabase.auth.signOut();

    if (error) {
      console.warn('Supabase signOut warning:', error.message);
    }

    // Return 204 No Content on successful logout
    return res.status(204).send();
  } catch (err) {
    console.error('Logout error:', err);
    return res.status(500).json({ error: 'Internal server error during logout' });
  }
});

module.exports = router;
