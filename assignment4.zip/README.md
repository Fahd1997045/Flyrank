# Auth Login & Protect — Supabase JWT Authentication API

A secure, production-grade authentication API built with **Node.js**, **Express**, **Supabase Auth (Identity Provider)**, and **Swagger UI** (OpenAPI 3.0.3).

This API implements the industry-standard **Trust Triangle**: Client ↔ Backend Server ↔ Identity Provider (Supabase). It issues cryptographically signed **JSON Web Tokens (JWTs)** upon login, guards private endpoints with a reusable **Bearer Token Verification Middleware**, and provides interactive API documentation with Bearer authentication in Swagger UI.

---

## 🏛️ Security Architecture: The Trust Triangle

```
      ┌─────────────────────────────────────────────────────────┐
      │                   CLIENT / FRONTEND                     │
      └───────┬─────────────────────────────────▲───────────────┘
              │                                 │
    1. Login Request                       2. JWT Pass
   (Email + Password)                     (Access Token)
              │                                 │
              ▼                                 │
   ┌────────────────────────────────────────────┴───────────────┐
   │         IDENTITY PROVIDER (IdP): Supabase Auth             │
   │  - Validates credentials & manages password hashing (BCrypt)│
   │  - Issues signed JWT Access Tokens & Refresh Tokens        │
   │  - Manages session lifecycle & revokes tokens              │
   └────────────────────────────────────────────▲───────────────┘
                                                │
                                       4. Token Verification
                                         supabase.auth.getUser()
                                                │
      ┌─────────────────────────────────────────┴───────────────┐
      │            BACKEND API SERVER: Express.js               │
      │                                                         │
      │  3. Incoming Request: Authorization: Bearer <token>     │
      │                                                         │
      │  ┌───────────────────────────────────────────────────┐  │
      │  │        authMiddleware (The Security Guard)        │  │
      │  │  - Extracts Bearer Token from HTTP Headers        │  │
      │  │  - Verifies token integrity via Supabase          │  │
      │  │  - Rejects with 401 Unauthorized if invalid       │  │
      │  │  - Injects validated user into req.user           │  │
      │  └─────────────────────────┬─────────────────────────┘  │
      │                            │                            │
      │                5. Unlocks Protected Doors               │
      │                            ▼                            │
      │             [GET /protected/profile]                    │
      │             [GET /protected/dashboard]                  │
      │             [POST /auth/logout]                         │
      └─────────────────────────────────────────────────────────┘
```

---

## 📸 Swagger UI with Bearer Token Authorization

Interactive documentation is hosted at `/docs`. The padlock icon indicates protected endpoints. Clicking **Authorize** allows entering your Bearer JWT token to test protected routes directly in the browser:

![Swagger UI with Bearer Auth](docs/swagger_ui.png)

---

## 🚀 Quick Start Guide

### Prerequisites
- [Node.js](https://nodejs.org/) (v18+ or v20+)
- npm
- A free [Supabase](https://supabase.com/) project (or default local sandbox)

### Installation
```bash
# Clone the repository
git clone https://github.com/Fahd1997045/assignment-4-auth.git
cd assignment-4-auth

# Install dependencies
npm install
```

### Environment Configuration (`.env`)
Create a `.env` file in the root directory (using `.env.example` as a template):

```env
PORT=3000
NODE_ENV=development
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_KEY=your-anon-public-key
```

> [!IMPORTANT]
> Your `.env` file is excluded in `.gitignore`. Never commit your private Supabase keys to GitHub.

### Running the Server
```bash
# Start server in production mode
npm start

# Or start in watch/development mode
npm run dev
```

The server will start at `http://localhost:3000`.

### Running Automated Test Suite
```bash
npm test
```

---

## 📡 REST API Reference

### Base URL: `http://localhost:3000`

| Method | Endpoint | Auth Required? | Purpose | Success Status | Error Statuses |
|---|---|---|---|---|---|
| `POST` | `/auth/signup` | No | Register a new user account | `201 Created` | `400 Bad Request` |
| `POST` | `/auth/login` | No | Authenticate user & return JWT | `200 OK` | `400 Bad Request`, `401 Unauthorized` |
| `POST` | `/auth/logout` | **Yes (Bearer JWT)** | Terminate active user session | `204 No Content` | `401 Unauthorized` |
| `GET` | `/public/info` | No | Read public, unprotected info | `200 OK` | — |
| `GET` | `/protected/profile`| **Yes (Bearer JWT)** | Read authenticated user claims | `200 OK` | `401 Unauthorized` |
| `GET` | `/protected/dashboard`| **Yes (Bearer JWT)**| Private dashboard statistics | `200 OK` | `401 Unauthorized` |
| `GET` | `/docs` | No | Interactive Swagger UI docs | `200 OK` | — |

---

## 🧪 Testing the Auth Flow via `curl`

### 1. Register a New Account (`POST /auth/signup`)
```bash
curl -i -X POST http://localhost:3000/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email": "developer@flyrank.ai", "password": "SuperSecurePassword123!"}'
```
*Response (`201 Created`):*
```json
{
  "message": "User registered successfully",
  "user": {
    "id": "a8123456-7890-abcd-ef01-234567890abc",
    "email": "developer@flyrank.ai"
  }
}
```

---

### 2. Log In & Receive JWT Pass (`POST /auth/login`)
```bash
curl -i -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "developer@flyrank.ai", "password": "SuperSecurePassword123!"}'
```
*Response (`200 OK`):*
```json
{
  "message": "Login successful",
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "k3j9sd8fk3...",
  "token_type": "bearer",
  "expires_in": 3600,
  "user": {
    "id": "a8123456-7890-abcd-ef01-234567890abc",
    "email": "developer@flyrank.ai"
  }
}
```

---

### 3. Access Public Route (`GET /public/info`)
```bash
curl -i -X GET http://localhost:3000/public/info
```
*Response (`200 OK`):*
```json
{
  "message": "Welcome stranger! This info is public.",
  "access": "unrestricted"
}
```

---

### 4. Access Protected Route Without Token (`GET /protected/profile`)
```bash
curl -i -X GET http://localhost:3000/protected/profile
```
*Response (`401 Unauthorized`):*
```json
{
  "error": "Access token required"
}
```

---

### 5. Access Protected Route With Valid Bearer Token (`GET /protected/profile`)
```bash
curl -i -X GET http://localhost:3000/protected/profile \
  -H "Authorization: Bearer <PASTE_YOUR_ACCESS_TOKEN_HERE>"
```
*Response (`200 OK`):*
```json
{
  "message": "Access granted to protected profile",
  "profile": {
    "id": "a8123456-7890-abcd-ef01-234567890abc",
    "email": "developer@flyrank.ai",
    "created_at": "2026-09-12T12:00:00.000Z",
    "role": "authenticated"
  }
}
```

---

### 6. Log Out (`POST /auth/logout`)
```bash
curl -i -X POST http://localhost:3000/auth/logout \
  -H "Authorization: Bearer <PASTE_YOUR_ACCESS_TOKEN_HERE>"
```
*Response (`204 No Content`)*

---

## 🤖 Stage 7: The AI Rematch (Analysis)

As part of the Stage 7 bonus, we conducted a rigorous comparative analysis of AI-generated auth architectures versus human-engineered security implementations:

### 1. Token Extraction & Format Parsing
- **Human Implementation**: Robustly checks `req.headers.authorization`, verifies the `Bearer ` prefix (case-sensitive and whitespace-trimmed), handles absent tokens, and returns descriptive `401 Unauthorized` responses before hitting the database.
- **Common AI Flaw**: Naive AI implementations often assume `req.headers.authorization.split(' ')[1]` is always defined, throwing uncaught `TypeError: Cannot read properties of undefined` on unauthenticated requests and causing server crashes (500) instead of clean 401s.

### 2. Error Code Accuracy (`400` vs `401` vs `404`)
- **Proper Standard**:
  - Missing input fields (`email`, `password`) -> `400 Bad Request`.
  - Invalid credentials or invalid/expired JWT -> `401 Unauthorized`.
  - Non-existent endpoints -> `404 Not Found`.
- **AI Pitfall**: LLMs frequently mix up 400 and 401, sometimes returning 400 for bad passwords or 500 for token verification errors.

### 3. Middleware Architecture & Separation of Concerns
- **Engineered Approach**: The `authenticateToken` middleware encapsulates all token validation logic in `src/middleware/authMiddleware.js`. Any route mounted under `router.use(authenticateToken)` or passed the middleware is automatically protected without boilerplate.

---

## 📜 Progressive Commit History

The repository was built strictly following the 6 progressive assignment stages:

```
af1dabb Stage 5: Swagger UI documentation with bearer auth
e65a2eb Stage 4: auth middleware and logout endpoint
36c326f Stage 3: profile route token verification
553174c Stage 2: public route and unverified protected route
846f614 Stage 1: signup and login routes working
d952c0d Stage 0: setup server and supabase client
```
