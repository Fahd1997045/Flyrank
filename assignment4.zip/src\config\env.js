const path = require('path');
const dotenv = require('dotenv');

// Load environment variables from .env
dotenv.config({ path: path.join(__dirname, '..', '..', '.env') });

const config = {
  PORT: process.env.PORT ? parseInt(process.env.PORT, 10) : 3000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  SUPABASE_URL: process.env.SUPABASE_URL || 'https://your-project-id.supabase.co',
  SUPABASE_KEY: process.env.SUPABASE_KEY || 'anon-public-key-placeholder'
};

module.exports = config;
